// module.exports = {
//     db: 'mongodb://localhost/catapultSports',
//     RESTAPIport: '5000',
// };
module.exports = {
    db: 'mongodb+srv://Robert:Professional@cluster0-m5kjg.mongodb.net/test?authSource=admin&replicaSet=Cluster0-shard-0&readPreference=primary&appname=MongoDB%20Compass%20Community&ssl=true',
    RESTAPIport: '5000',
};