// export const RESTAPIUrl = 'http://192.168.100.118:5000';
// export const SOCKET_URI = 'http://192.168.100.118:5000';

export const RESTAPIUrl = 'https://anonymous-video-chat.herokuapp.com';
export const SOCKET_URI = 'https://anonymous-video-chat.herokuapp.com';